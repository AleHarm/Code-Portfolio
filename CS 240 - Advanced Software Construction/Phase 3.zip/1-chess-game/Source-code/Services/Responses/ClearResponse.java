package Services.Responses;

public class ClearResponse extends Response{

    public ClearResponse(){}
}
