package Services.Responses;

public class LogoutResponse extends Response{

    public LogoutResponse(){}
}
