package Services.Responses;

public class JoinGameResponse extends Response{

    public JoinGameResponse() {}
}
