package Services.Requests;

public class CreateGameRequest {

    String gameName;

    public CreateGameRequest() {
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }
}
