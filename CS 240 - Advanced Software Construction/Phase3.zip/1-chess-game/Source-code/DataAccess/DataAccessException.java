package DataAccess;

public class DataAccessException extends Exception {
}
