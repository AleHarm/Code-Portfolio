package Services;

import DatabaseTEMP.DatabaseTEMP;
import Services.Responses.Response;

public class ClearService {

    public static Response clear(){

        Response clearResponse = new Response();

        //Clear database
        DatabaseTEMP.getDatabase().clear();

        //Return info
        clearResponse.setSuccess(true);
        return clearResponse;
    }
}
